package myservlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.sql.*;

@WebServlet("/myServlet")
public class myServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{		
		response.setContentType("text/html");  
		PrintWriter out = response.getWriter();		  
	
		String nme=request.getParameter("userName");  
		String pass=request.getParameter("pass");  
		String mail=request.getParameter("userEmail");  
		String age=request.getParameter("userAge");  
		String mob=request.getParameter("userMob");
		String address=request.getParameter("userAddress");		
		try
		{  
		Class.forName("com.mysql.jdbc.Driver");  
		Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/website","root","root");		  
		PreparedStatement ps=con.prepareStatement("insert into registration values(?,?,?,?,?,?)");  
		ps.setString(1,nme);  
		ps.setString(2,mob);  
		ps.setString(3,age);  
		ps.setString(4,mail);
		ps.setString(5,address);
		ps.setString(6,pass);		
		int i=ps.executeUpdate();  
		if(i>0)  
		out.print("You are successfully registered...");		      
		con.close();            
		}
		catch (Exception e2) 
		{
			System.out.println(e2);
		}  		          
		out.close();	
	}
}
